import Achivements from "./Achievements/Achievements";
import Fproject from "./Fproject/Fproject";
function Projects(){
    return(
        <div>
            <Fproject/>
            <Achivements />
            
        </div>
    )
}
export default Projects;